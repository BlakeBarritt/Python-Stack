from django.shortcuts import render, redirect
from .models import books, authors

def index(request):
    context = {
        'all_books' : books.objects.all()
    }
    return render(request, 'index.html', context)

# --------------- Create one book ------------------- 
def addBook(request):
# 1. Grab POST information, create a new book
    new_book = books.objects.create(
        title = request.POST['title'],
        desc = request.POST['desc']
    )
    print(new_book.id)
# 2. Return redirect to index route
    return redirect('/')

# ---------------- Read one book ---------------------
def bookInfo(request, book_id):
    context = {
        'one_book' : books.objects.get(id = book_id),
        'all_authors' : authors.objects.all()
        
    }
    print(f'Book ID is: {book_id}')
    return render(request, 'bookinfo.html', context)

# Updating authors to a book
def addAuthor(request):
    book_id = request.POST['book_id']
# # 1. Grab book from DB
    book = books.objects.get(id = int(book_id))
# 2. Grab author from db
    author = authors.objects.get(id = int(request.POST['author_id']))
# 3. Create relationship between book and author
    book.authors.add(author)
# 4. return redirect /books/<int:book_id>
    return redirect(f'/books/{book_id}')


# ---------- Display Author page --------
def author(request):
# Create context dictionary for all others
    context = {
        'all_authors' : authors.objects.all()
    }
# render the addauthor.html page with context
    return render(request, 'addauthor.html', context)


def newAuthor(request):
# 1. Grab POST information, create a new author
    new_author = authors.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        notes = request.POST['notes']
    )
    print(new_author.id)
# 2. Return redirect to index route
    return redirect('/authors')
# 2. Display table with all authors in database
# 3. Create anchor tag that redirects to authorInfo page
# 4. Return render page

def authorInfo(request, author_id):
    context = {
        'one_author' : authors.objects.get(id = author_id),
        'all_books' : books.objects.all()
    }
    print(f'Author ID is: {author_id}')
    return render(request, 'authorInfo.html', context)