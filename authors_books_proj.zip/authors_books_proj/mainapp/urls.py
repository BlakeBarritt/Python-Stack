from django.urls import path     
from . import views
urlpatterns = [
    path('', views.index),
    path('add/book', views.addBook),
    path('books/<int:book_id>', views.bookInfo),
    path('books/add_author', views.addAuthor),
    path('authors', views.author),
    path('authors/new', views.newAuthor),
    path('authors/<int:author_id>', views.authorInfo)
]


# Index Page: 
#       Table of all books in database
#       Form for adding book to db

# Template for each book
#       Displays book and it's details, including all authors
#       Form with dropdown of all authors in DB
#           Add buttton on form to add author to book

# Template for creating authors
#       Form to add authors
#       Table of all authors in db

# Template for each author
#       Displays author and their details, including all books
#       Form with dropdown of all books in DB
#           Add buttton on form to add books to author