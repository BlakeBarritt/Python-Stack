from django.shortcuts import render, redirect

import random

def index(request):
    # need line 7 otherwise refresh will generate a new number everytime, almost impossible to win
    if 'random' not in request.session: 
        request.session['random'] = random.randint(1, 100)
    return render(request, 'index.html')

def pick(request):
    print('got submission')
    
    if(request.session['random'] > int(request.POST['pick'])):
        request.session['pick'] = 'too low'

    if(request.session['random'] < int(request.POST['pick'])):
        request.session['pick'] = 'too high'


    elif(request.session['random'] == int(request.POST['pick'])):
            request.session['pick'] = 'correct'
    
    return redirect('/')

def destroy(request):
    del request.session["random"]
    return redirect('/')