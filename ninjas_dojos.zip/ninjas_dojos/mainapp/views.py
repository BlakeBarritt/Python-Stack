from django.shortcuts import render, redirect
from .models import dojos, ninjas


def index(request):
    context = {
        "all_dojos" : dojos.objects.all()
    }
    return render(request, 'index.html', context)

def addDojo(request):
    new_dojos = dojos.objects.create(
    name = request.POST['name'],
    city = request.POST['city'],
    state = request.POST['state']
    )
    return redirect('/')

def addNinja(request):
    new_ninjas = ninjas.objects.create(
    first_name = request.POST['first_name'],
    last_name = request.POST['last_name'],
    dojo = dojos.objects.get(city = request.POST['dojo']),
    state = request.POST['state']
    )
    return redirect('/')