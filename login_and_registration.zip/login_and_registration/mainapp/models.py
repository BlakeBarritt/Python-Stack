from django.db import models
import re

# Create your models here.
class UserManager(models.Manager):
    def validate_registration(self, postData):
        errors = {}

        if len(postData['first_name']) < 2:
            errors['first_name'] = "First Name must be at least two characters"

        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last Name must be at least two characters"

        # if (not str.isalpha(postData['first_name'])):
        #     errors['first_name'] = "First Name cannot contain numbers or symbols"
            
        # if (not str.isalpha(postData['last_name'])):
        #     errors['first_name'] = "Last Name cannot contain numbers or symbols"
            
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = "Invalid Email Address"
       
        user_list = User.objects.filter(email = postData['email'])
        # Checking to see if email is already in the database, filter will not break like get command will
        if len(user_list) > 0:
            errors['email_duplicate'] = "This email already exists"
            
        if len(postData['password']) < 9:
            errors['password'] = "Your password must be at least eight characters"

        if postData['password'] != postData['confirm_password']:
            errors['match_password'] = "Your passwords do not match"
        return errors


class User(models.Model):
    first_name = models.CharField(max_length = 45)
    last_name = models.CharField(max_length = 45)
    email = models.CharField(max_length = 45)
    password = models.CharField(max_length = 255)

    objects = UserManager()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)