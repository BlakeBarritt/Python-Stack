from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("process/register", views.register),
    path("process/login", views.login),
    path("success", views.success),
    path("logout", views.logout)
]