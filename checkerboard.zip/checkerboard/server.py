from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def eightByEight():
    return render_template('index.html', x = 4, y = 4)

# Should be 8x8 checkerboard, x,y = 4 as each is doubled in html file



@app.route('/4')
def eightByFour():
    return render_template('index.html', x=int('4'), y=int('2'))

# Should be 8x4 checkerboard


@app.route('/<x>/<y>')
def x_by_y(x,y):
    return render_template('index.html', x=int(x), y=int(y))


if __name__ == "__main__":
    app.run(debug=True)
