from django.urls import path     
from . import views
urlpatterns = [
    path('', views.index),	   
    path("result",views.result)
]


# root route("/") show page with form
    # form: Your Name, Dojo Location, Favorite Lanague:, Comment (optional)
# have "/result" route display form info on new HTML page

# Ninja Bonuses: Use CSS framework