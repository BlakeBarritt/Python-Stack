from django.urls import path     
from . import views
urlpatterns = [
    path('', views.route),
    path('shows', views.index),
    path('shows/new', views.newShow),
    path('shows/create', views.createShow),
    path('shows/<int:show_id>', views.showInfo),
    path('shows/<int:show_id>/edit', views.editShow),
    path('shows/<int:show_id>/change', views.change),
    path('shows/<int:show_id>/delete', views.delete)
]