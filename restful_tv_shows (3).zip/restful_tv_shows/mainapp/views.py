from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Shows

def route(request):
    return redirect('/shows')

def index(request):
    context = {
        'all_shows' : Shows.objects.all()
    }
    return render(request, 'shows.html', context)

def newShow(request):
    return render(request, 'newShow.html')

def createShow(request):
# Validate the POST information, store errors coming back from validation function
    print(request.POST)
    errors = Shows.objects.validate_shows(request.POST)
#  Validations DO NOT pass
    if len(errors) > 0: 
        for key, value in errors.items():
            messages.error(request, value)
        # redirect the user back to the form to fix the errors
        return redirect('/shows/new')
    
# Validations DO pass
# Grab POST information and create Show
    else:
        new_show = Shows.objects.create(
            title = request.POST['title'],
            network = request.POST['network'],
            release_date = request.POST['release_date'],
            desc = request.POST['desc']
        )
        print (new_show.id)
        return redirect(f'/shows/{new_show.id}')

def editShow(request, show_id):
    one_show = Shows.objects.get(id = show_id)
    context = {
        'show' : one_show
    }
    return render(request, 'editShow.html', context)

def change(request, show_id):
    errors = Shows.objects.validate_shows(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/shows/{show_id}/edit")
    
    else:
        update_show = Shows.objects.get(id = show_id)
        update_show.title = request.POST['title']
        update_show.network = request.POST['network']
        update_show.release_date = request.POST['release_date']
        update_show.desc = request.POST['desc']
        update_show.save()
    
        return redirect(f'/shows/{show_id}')

def showInfo(request, show_id):
    one_show = Shows.objects.get(id = show_id)
    context = {
        'show' : one_show
    }
    return render(request, 'showInfo.html', context)

def delete(request, show_id):
    delete_show = Shows.objects.get(id = show_id)
    delete_show.delete()
    return redirect('/shows')
