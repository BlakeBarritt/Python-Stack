from django.db import models

class ShowsManager(models.Manager):
    def validate_shows(self, postData):
        print(postData)
#  Validate the Add a TV Show form to ensure all fields are populated appropriately before adding to the database.
        errors = {}
#     1. Title > 2 chars
        if "title" not in postData:
            errors['title'] = 'Title must be longer than 2 characters'
        elif len(postData['title']) < 2:
            errors['title'] = 'Title must be longer than 2 characters'
#     2. Network >= 3 chars
        if "network" not in postData:
            errors['network'] = 'Network must be at least 3 characters'
        elif len(postData['network']) < 3:
            errors['network'] = 'Network must be at least 3 characters'
            
        if "release_date" not in postData:
            errors['release_date'] = 'Must have a release date'
        elif len(postData['release_date']) <= 3:
            errors['release_date'] = 'Must have a release date'
            
#     3. Desc >= 10 chars
        if "desc" not in postData:
            errors['desc'] = 'Description must be at least 10 characters'
        elif len(postData['desc']) <= 10:
            errors['desc'] = 'Description must be at least 10 characters'
        return errors


class Shows(models.Model):
    title = models.CharField(max_length = 255)
    network = models.CharField(max_length = 255)
    release_date = models.DateTimeField()
    desc = models.CharField(max_length = 255)
    
    objects = ShowsManager() 
    # by declaring objects, overriding inherited objects class from Django, but still retaining CRUD commands and validation functions
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    


# # Display errors on the Add a TV Show form if the information is invalid.	

# # Validate the Edit Show form with the same validations as creation.
#     1. Same as create validations

# Display errors on the Edit Show form if the information is invalid.	