User.objects.create(first_name="Jim", last_name = "Bear", email_address="jim@gmail.com", age = 50)
User.objects.create(first_name="Joe", last_name = "cat", email_address="joe@gmail.com", age = 30)
User.objects.create(first_name="John", last_name = "dog", email_address="john@gmail.com", age = 20)

User.objects.all()

User.objects.last()

User.objects.first()

user_to_update = User.objects.get(id=3)
user_to_update.last_name = "pancakes"
user_to_update.save()

user_to_delete = User.objects.get(id=2)
user_to_delete.delete()

User.objects.all()
User.objects.all().order_by("first_name")