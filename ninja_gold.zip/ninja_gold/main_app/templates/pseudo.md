1. Html page
    4 forms (EACH FORM IS GOING TO HAVE HIDDEN INPUT)
        <input type = "hidden" name ="which_form" value = "farm">
        <input type = "hidden" name ="which_form" value = "cave">
        <input type = "hidden" name ="which_form" value = "house">
        <input type = "hidden" name ="which_form" value = "casino">
    Gold Amount Display
        -- {{request.session.gold}}
    Activity Log
        -- USE A FOR LOOP {% for something in request.session.activities %}

2. URLS.py
path('', views.index) -> render html page
path('process_money', views.process) -> determine amount of gold and add to total

3. views.py
def index(request):
    INITIALIZE GOLD TO 0 IF THIS IS FIRST TIME VISITING NINJA GOLD
    - request.session['gold'] = 0
    INITIALIZE ACTIVITES TO [] -- an empty list -- IF THIS IS FIRST TIME VISITING NINJA GOLD
    return render(request,'index.html')
    - request.session['activities'] = []

def process(request):
    if request.pot['which_form'] == farm:
        CHOOSE RANDOM AMOUNT BETWEEN 10-20 AND THEN ADD TO GOLD IN SESSION
        CREATE A LOG STRING AND APPEND TO ACTIVITIES IN SESSION
        CREATE string = f'Earned {} gold from Farm!"
    elif request.pot['which_form'] == cave:
        CHOOSE RANDOM AMOUNT BETWEEN 5-10 AND THEN ADD TO GOLD IN SESSION
        CREATE A LOG STRING AND APPEND TO ACTIVITIES IN SESSION
        CREATE string = f'Earned {} gold from Cave!"
    elif request.pot['which_form'] == house:
        CHOOSE RANDOM AMOUNT BETWEEN 2-5 AND THEN ADD TO GOLD IN SESSION
        CREATE A LOG STRING AND APPEND TO ACTIVITIES IN SESSION
        CREATE string = f'Earned {} gold from House!"
    elif request.pot['which_form'] == casino:
        CHOOSE RANDOM AMOUNT BETWEEN -50--50 AND THEN ADD TO GOLD IN SESSION
        CREATE A LOG STRING AND APPEND TO ACTIVITIES IN SESSION
        CREATE string = f'Earned {} gold from Casino!" // CREATE string = f'Entered a casino and lost {} gold from Farm... Ouch"
    
    return redirect('/')
