from django.shortcuts import render, redirect

import random

def index(request):
# INITIALIZE GOLD TO 0 IF THIS IS FIRST TIME VISITING NINJA GOLD
    if 'gold' not in request.session:
        request.session['gold'] = 0
    if 'activities' not in request.session:
        request.session['activities'] = []
# INITIALIZE ACTIVITES TO [] -- an empty list -- IF THIS IS FIRST TIME VISITING NINJA GOLD
    return render(request,'index.html')

def process(request):
    if request.POST['location'] == 'farm':
        gold = random.randint(10, 20)
# CHOOSE RANDOM AMOUNT BETWEEN 10-20 AND THEN ADD TO GOLD IN SESSION
        request.session['gold'] += gold
        request.session['activities'].append(f'Earned {gold} gold from Farm!')
# CREATE A LOG STRING AND APPEND TO ACTIVITIES IN SESSION
# Have to save session after append

    elif request.POST['location'] == 'cave':
        gold = random.randint(5, 10)
        request.session['gold'] += gold
        request.session['activities'].append(f'Earned {gold} gold from Cave!')
        
    elif request.POST['location'] == 'house':
        gold = random.randint(2, 5)
        request.session['gold'] += gold
        request.session['activities'].append(f'Earned {gold} gold from House!')

    elif request.POST['location'] == 'casino':
        gold = random.randint(-50, 50)
        request.session['gold'] += gold

        if (gold > 0):
            request.session['activities'].append(f'Entered a Casino and earned {gold} gold from Casino!')
            
        elif (gold < 0):
            request.session['activities'].append(f'Entered a Casino and lost {gold} gold.. Ouch!')

    return redirect('/')

def destroy(request):
    del request.session["activities"]
    return redirect('/')
        
        # destroy function from Counter assignment not working yet, moving on as finished basic assignment



